create
    definer = db2007u1@`%` procedure proc_news_insert(IN News_Tittle_Ip varchar(50), IN News_Content_Ip text,
                                                      IN News_Image_Link_Ip varchar(50))
BEGIN 
	INSERT INTO News(News_Tittle,News_Content,News_Image_Link)
		VALUES(News_Tittle_Ip,News_Content_Ip,News_Image_Link_Ip);
END;

