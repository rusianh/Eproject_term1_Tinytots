create
    definer = db2007u1@`%` procedure proc_configution_update(IN Configution_ID int, IN SystemKey_Ip varchar(200),
                                                             IN SystemValue_Ip varchar(200))
BEGIN 
	UPDATE Configution SET SystemKey = SystemKey_Ip,SystemValue = SystemValue_Ip
		WHERE ConfigutionID = Configution_ID;
END;

