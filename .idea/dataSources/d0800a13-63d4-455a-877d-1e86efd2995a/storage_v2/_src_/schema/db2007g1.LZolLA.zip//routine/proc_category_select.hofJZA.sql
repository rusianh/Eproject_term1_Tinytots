create
    definer = db2007u1@`%` procedure proc_category_select(IN Category_ID char(8))
BEGIN 
	SELECT Name_Category,Description_Category
		FROM Category
			WHERE CategoryID = Category_ID;
END;

