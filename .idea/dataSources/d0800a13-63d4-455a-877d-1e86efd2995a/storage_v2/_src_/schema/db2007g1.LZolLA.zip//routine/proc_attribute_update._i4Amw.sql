create
    definer = db2007u1@`%` procedure proc_attribute_update(IN Attribute_ID char(8), IN Attribute_Name_Ip varchar(50))
BEGIN 
	UPDATE Attribute SET Attribute_Name = Attribute_Name_Ip
		WHERE AttributeID = Attribute_ID;
END;

