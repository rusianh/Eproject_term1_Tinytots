create
    definer = db2007u1@`%` procedure proc_productAttribute_insert(IN Product_ID char(8), IN Attribute_ID char(8))
BEGIN 
	INSERT INTO Product_Attribute(ProductID,AttributeID)
		VALUES(Product_ID,Attribute_ID);
END;

