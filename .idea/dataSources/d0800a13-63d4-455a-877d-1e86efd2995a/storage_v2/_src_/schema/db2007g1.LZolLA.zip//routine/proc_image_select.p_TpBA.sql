create
    definer = db2007u1@`%` procedure proc_image_select(IN Image_ID int)
BEGIN 
	SELECT Image_Name,Image_Link,ProductID
		FROM Images
			WHERE ImageID = Image_ID;
END;

