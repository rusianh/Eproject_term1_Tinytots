create
    definer = db2007u1@`%` procedure proc_productAttribute_select(IN ProductAttribute_ID int)
BEGIN 
	SELECT ProductID,AttributeID
		FROM Product_Attribute
			WHERE ProductAttributeID = ProductAttribute_ID;
END;

