create
    definer = db2007u1@`%` procedure proc_transport_select(IN Transport_ID int)
BEGIN 
	SELECT Transport_Name,Transport_Phone
		FROM Transport
			WHERE TransportID = Transport_ID;
END;

