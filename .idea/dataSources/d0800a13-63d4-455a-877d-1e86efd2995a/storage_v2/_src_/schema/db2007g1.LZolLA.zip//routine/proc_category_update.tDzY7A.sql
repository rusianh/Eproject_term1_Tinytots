create
    definer = db2007u1@`%` procedure proc_category_update(IN Category_ID char(8), IN Name_Category_Ip varchar(50),
                                                          IN Description_Category_Ip varchar(200))
BEGIN 
	UPDATE Category SET Name_Category = Name_Category_Ip,Description_Category = Description_Category_Ip
		WHERE CategoryID = Category_ID;
END;

