create
    definer = db2007u1@`%` procedure proc_news_update(IN News_ID int, IN News_Tittle_Ip varchar(50),
                                                      IN News_Content_Ip text, IN News_Image_Link_Ip varchar(50))
BEGIN 
	UPDATE News SET News_Tittle = News_Tittle_Ip,News_Content = News_Content_Ip,News_Image_Link = News_Image_Link_Ip
		WHERE NewsID = News_ID;
END;

