create
    definer = db2007u1@`%` procedure proc_image_insert(IN Image_Name_Ip char(8), IN Image_Link_Ip varchar(200),
                                                       IN Product_ID char(8))
BEGIN 
	INSERT INTO Images(Image_Name,Image_Link,ProductID)
		VALUES(Image_Name_Ip,Image_Link_Ip,Product_ID);
END;

