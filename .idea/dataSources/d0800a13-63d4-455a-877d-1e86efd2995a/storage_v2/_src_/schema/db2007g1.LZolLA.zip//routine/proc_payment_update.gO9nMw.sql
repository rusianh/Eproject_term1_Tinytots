create
    definer = db2007u1@`%` procedure proc_payment_update(IN Payment_ID int, IN Payment_Name_Ip varchar(50))
BEGIN 
	UPDATE Payment SET Payment_Name = Payment_Name_Ip
		WHERE PaymentID = Payment_ID;
END;

