create
    definer = db2007u1@`%` procedure proc_attributeValue_select(IN AttributeValue_ID int)
BEGIN 
	SELECT Attribute_Value,AttributeID
		FROM AttributeValue
			WHERE AttributeValueID = AttributeValue_ID;
END;

