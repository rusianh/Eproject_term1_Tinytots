create
    definer = db2007u1@`%` procedure proc_productCategory_insert(IN Product_ID char(8), IN Category_ID char(8))
BEGIN 
	INSERT INTO Product_Category(ProductID,CategoryID)
		VALUES(Product_ID,Category_ID);
END;

