create
    definer = db2007u1@`%` procedure proc_faq_update(IN FAQ_ID int, IN Subject_Ip varchar(50),
                                                     IN Question_Ip varchar(200), IN Answer_Ip varchar(200))
BEGIN 
	UPDATE FAQ SET Subject = Subject_Ip,Question = Question_Ip,Answer = Answer_Ip
		WHERE FAQID = FAQ_ID;
END;

