create
    definer = db2007u1@`%` procedure proc_brand_select(IN Brand_ID char(8))
BEGIN 
	SELECT BrandID ,Brand_Address, BrandName
		FROM Brand
			WHERE BrandID = Brand_ID;
END;

