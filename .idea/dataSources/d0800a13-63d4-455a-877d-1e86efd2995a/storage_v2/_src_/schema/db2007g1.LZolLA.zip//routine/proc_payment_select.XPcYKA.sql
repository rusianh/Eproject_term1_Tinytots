create
    definer = db2007u1@`%` procedure proc_payment_select(IN Payment_ID int)
BEGIN 
	SELECT Payment_Name
		FROM Payment
			WHERE PaymentID = Payment_ID;
END;

