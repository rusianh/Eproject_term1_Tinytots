create
    definer = db2007u1@`%` procedure proc_faq_select(IN FAQ_ID int)
BEGIN 
	SELECT Subject,Question,Answer
		FROM FAQ
			WHERE FAQID = FAQ_ID;
END;

