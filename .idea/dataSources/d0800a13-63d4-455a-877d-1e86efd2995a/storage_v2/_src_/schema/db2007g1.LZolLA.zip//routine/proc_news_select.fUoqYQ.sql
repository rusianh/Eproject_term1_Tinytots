create
    definer = db2007u1@`%` procedure proc_news_select(IN News_ID int)
BEGIN 
	SELECT News_Tittle,News_Content,News_Image_Link
		FROM News
			WHERE NewsID = News_ID;
END;

