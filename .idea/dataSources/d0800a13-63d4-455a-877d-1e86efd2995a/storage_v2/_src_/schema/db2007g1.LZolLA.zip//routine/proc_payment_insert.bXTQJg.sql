create
    definer = db2007u1@`%` procedure proc_payment_insert(IN Payment_Name_Ip varchar(50))
BEGIN 
	INSERT INTO Payment(Payment_Name)
		VALUES(Payment_Name_Ip);
END;

