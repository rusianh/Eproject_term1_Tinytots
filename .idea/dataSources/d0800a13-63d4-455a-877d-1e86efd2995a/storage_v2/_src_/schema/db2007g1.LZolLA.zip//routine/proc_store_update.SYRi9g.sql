create
    definer = db2007u1@`%` procedure proc_store_update(IN Store_ID int, IN Store_Name_Ip varchar(50),
                                                       IN Store_Phone_Ip varchar(15), IN Store_Address_Ip varchar(200))
BEGIN 
	UPDATE Store SET Store_Name = Store_Name_Ip,Store_Phone = Store_Phone_Ip,Store_Address = Store_Address_Ip
		WHERE StoreID = Store_ID;
END;

