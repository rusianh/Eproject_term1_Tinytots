create
    definer = db2007u1@`%` procedure proc_category_insert(IN Category_ID char(8), IN Name_Category_Ip varchar(50),
                                                          IN Description_Category_Ip varchar(200))
BEGIN 
	INSERT INTO Category(CategoryID,Name_Category,Description_Category)
		VALUES(Category_ID,Name_Category_Ip,Description_Category_Ip);
END;

