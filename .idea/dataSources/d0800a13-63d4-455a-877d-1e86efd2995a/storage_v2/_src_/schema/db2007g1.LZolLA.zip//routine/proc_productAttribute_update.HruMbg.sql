create
    definer = db2007u1@`%` procedure proc_productAttribute_update(IN ProductAttribute_ID int, IN Product_ID char(8),
                                                                  IN Attribute_ID char(8))
BEGIN 
	UPDATE Product_Attribute SET ProductID = Product_ID,AttributeID = Attribute_ID
		WHERE ProductAttributeID = ProductAttribute_ID;
END;

