create
    definer = db2007u1@`%` procedure proc_orders_update(IN Order_ID char(8), IN Payment_ID int, IN Transport_ID int,
                                                        IN StatusOrder_Ip varchar(50))
BEGIN 
	UPDATE Orders SET PaymentID = Payment_ID,TransportID = Transport_ID,StatusOrder = StatusOrder_Ip
		WHERE OrderID = Order_ID;
END;

