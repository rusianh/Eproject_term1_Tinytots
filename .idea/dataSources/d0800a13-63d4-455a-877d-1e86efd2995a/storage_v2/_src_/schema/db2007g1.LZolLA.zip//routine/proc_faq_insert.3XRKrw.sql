create
    definer = db2007u1@`%` procedure proc_faq_insert(IN Subject_Ip varchar(50), IN Question_Ip varchar(200),
                                                     IN Answer_Ip varchar(200))
BEGIN 
	INSERT INTO FAQ(Subject,Question,Answer)
		VALUES(Subject_Ip,Question_Ip,Answer_Ip);
END;

