create
    definer = db2007u1@`%` procedure proc_contact_select(IN Contact_ID int)
BEGIN 
	SELECT Type_Contact,Contact_Name,Contact_Phone,Contact_Email
		FROM Contact
			WHERE ContactID = Contact_ID;
END;

