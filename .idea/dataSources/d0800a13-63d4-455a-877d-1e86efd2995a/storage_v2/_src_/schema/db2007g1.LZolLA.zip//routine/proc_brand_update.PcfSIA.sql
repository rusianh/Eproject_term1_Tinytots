create
    definer = db2007u1@`%` procedure proc_brand_update(IN Brand_ID char(8), IN Brand_Name_Ip varchar(50),
                                                       IN Brand_Address_Ip varchar(200))
BEGIN 
	UPDATE Brand SET Brand_Name = Brand_Name_Ip,Brand_Address = Brand_Address_Ip
		WHERE BrandID = Brand_ID;
END;

