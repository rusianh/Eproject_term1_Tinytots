create
    definer = db2007u1@`%` procedure proc_orderdetail_update(IN OrderDetail_ID char(8), IN Order_ID char(8),
                                                             IN Order_Name_Ip varchar(50),
                                                             IN Order_Phone_Ip varchar(15),
                                                             IN Order_Address_Ip varchar(200), IN Product_ID char(8),
                                                             IN Quantity_Ip int)
BEGIN 
	UPDATE OrderDetail SET OrderID = Order_ID,Order_Name = Order_Name_Ip,Order_Phone = Order_Phone_Ip,Order_Address = Order_Address_Ip,ProductID = Product_ID,Quantity = Quantity_Ip
		WHERE OrderDetailID = OrderDetail_ID;
END;

