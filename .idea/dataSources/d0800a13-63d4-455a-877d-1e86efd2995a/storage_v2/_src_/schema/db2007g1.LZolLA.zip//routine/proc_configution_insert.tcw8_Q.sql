create
    definer = db2007u1@`%` procedure proc_configution_insert(IN SystemKey_Ip varchar(200), IN SystemValue_Ip varchar(200))
BEGIN 
	INSERT INTO Configution(SystemKey,SystemValue)
		VALUES(SystemKey_Ip,SystemValue_Ip);
END;

