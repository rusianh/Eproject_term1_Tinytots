create
    definer = db2007u1@`%` procedure proc_productCategory_update(IN ProductCategory_ID int, IN Product_ID char(8),
                                                                 IN Category_ID char(8))
BEGIN 
	UPDATE Product_Category SET ProductID = Product_ID,CategoryID = Category_ID
		WHERE ProductCategoryID = ProductCategory_ID;
END;

