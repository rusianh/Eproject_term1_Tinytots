create
    definer = db2007u1@`%` procedure proc_orders_select(IN Order_ID char(8))
BEGIN 
	SELECT PaymentID,TransportID,StatusOrder
		FROM Orders
			WHERE OrderID = Order_ID;
END;

