create
    definer = db2007u1@`%` procedure proc_transport_update(IN Transport_ID int, IN Transport_Name_Ip varchar(50),
                                                           IN Transport_Phone_Ip varchar(15))
BEGIN 
	UPDATE Transport SET Transport_Name = Transport_Name_Ip,Transport_Phone = Transport_Phone_Ip
		WHERE TransportID = Transport_ID;
END;

