create
    definer = db2007u1@`%` procedure proc_store_insert(IN Store_Name_Ip varchar(50), IN Store_Phone_Ip varchar(15),
                                                       IN Store_Address_Ip varchar(200))
BEGIN 
	INSERT INTO Store(Store_Name,Store_Phone,Store_Address)
		VALUES(Store_Name_Ip,Store_Phone_Ip,Store_Address_Ip);
END;

