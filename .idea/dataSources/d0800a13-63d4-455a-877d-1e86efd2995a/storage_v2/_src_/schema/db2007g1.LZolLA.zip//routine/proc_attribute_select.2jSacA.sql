create
    definer = db2007u1@`%` procedure proc_attribute_select(IN Attribute_ID char(8))
BEGIN 
	SELECT Attribute_Name
		FROM Attribute
			WHERE AttributeID = Attribute_ID;
END;

