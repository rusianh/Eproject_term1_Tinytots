create
    definer = db2007u1@`%` procedure proc_contact_insert(IN Type_Contact_Ip varchar(20), IN Contact_Name_Ip varchar(50),
                                                         IN Contact_Phone_Ip varchar(15),
                                                         IN Contact_Email_Ip varchar(50))
BEGIN 
	INSERT INTO Contact(Type_Contact,Contact_Name,Contact_Phone,Contact_Email)
		VALUES(Type_Contact_Ip,Contact_Name_Ip,Contact_Phone_Ip,Contact_Email_Ip);
END;

