create
    definer = db2007u1@`%` procedure proc_admin_insert(IN UserName_Ip varchar(50), IN Password_Ip varchar(50),
                                                       IN Name_Admin_Ip varchar(50))
BEGIN 
	INSERT INTO Admins(UserName,Password,Name_Admin)
		VALUES(UserName_Ip,Password_Ip,Name_Admin_Ip);
END;

