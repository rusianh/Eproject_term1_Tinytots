create
    definer = db2007u1@`%` procedure proc_product_insert(IN Product_ID char(8), IN Product_Name_Ip varchar(50),
                                                         IN Download_Ip varchar(50),
                                                         IN Description_Product_Ip varchar(200))
BEGIN 
	INSERT INTO Product(ProductID,Product_Name,Download,Description_Product)
		VALUES(Product_ID,Product_Name_Ip,Download_Ip,Description_Product_Ip);
END;

