create
    definer = db2007u1@`%` procedure proc_attributeValue_update(IN AttributeValue_ID int,
                                                                IN Attribute_Value_Ip varchar(20),
                                                                IN Attribute_ID char(8))
BEGIN 
	UPDATE AttributeValue SET Attribute_Value = Attribute_Value_Ip,AttributeID = Attribute_ID
		WHERE AttributeValueID = AttributeValue_ID;
END;

