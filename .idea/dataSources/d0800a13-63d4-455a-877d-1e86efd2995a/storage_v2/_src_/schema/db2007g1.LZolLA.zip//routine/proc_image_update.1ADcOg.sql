create
    definer = db2007u1@`%` procedure proc_image_update(IN Image_ID int, IN Image_Name_Ip char(8),
                                                       IN Image_Link_Ip varchar(200), IN Product_ID char(8))
BEGIN 
	UPDATE Images SET Image_Name = Image_Name_Ip,Image_Link = Image_Link_Ip,ProductID = Product_ID
		WHERE ImageID = Image_ID;
END;

