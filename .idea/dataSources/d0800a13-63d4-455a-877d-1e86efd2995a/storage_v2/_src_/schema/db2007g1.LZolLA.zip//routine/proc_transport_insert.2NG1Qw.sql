create
    definer = db2007u1@`%` procedure proc_transport_insert(IN Transport_Name_Ip varchar(50), IN Transport_Phone_Ip varchar(15))
BEGIN 
	INSERT INTO Transport(Transport_Name,Transport_Phone)
		VALUES(Transport_Name_Ip,Transport_Phone_Ip);
END;

