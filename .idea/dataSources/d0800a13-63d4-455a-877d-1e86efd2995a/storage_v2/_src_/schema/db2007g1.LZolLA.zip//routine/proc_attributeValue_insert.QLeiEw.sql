create
    definer = db2007u1@`%` procedure proc_attributeValue_insert(IN Attribute_Value_Ip varchar(20), IN Attribute_ID char(8))
BEGIN 
	INSERT INTO AttributeValue(Attribute_Value,AttributeID)
		VALUES(Attribute_Value_Ip,Attribute_ID);
END;

