create
    definer = db2007u1@`%` procedure proc_productBrand_insert(IN Product_ID char(8), IN Brand_ID char(8))
BEGIN 
	INSERT INTO Product_Brand(ProductID,BrandID)
		VALUES(Product_ID,Brand_ID);
END;

