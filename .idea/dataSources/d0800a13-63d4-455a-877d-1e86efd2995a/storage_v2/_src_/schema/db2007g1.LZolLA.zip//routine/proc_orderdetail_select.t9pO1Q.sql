create
    definer = db2007u1@`%` procedure proc_orderdetail_select(IN OrderDetail_ID char(8))
BEGIN 
	SELECT e.Order_Name,e.Order_Phone,e.Order_Address,a.Product_Name,e.Quantity,d.Payment_Name,c.Transport_Name,b.StatusOrder 
		FROM Product a,Orders b,Transport c,Payment d,OrderDetail e
			WHERE a.ProductID = e.ProductID AND d.PaymentID = b.PaymentID AND c.TransportID = b.TransportID AND b.OrderID = e.OrderID 
				AND e.OrderDetailID = OrderDetail_ID;
END;

