create
    definer = db2007u1@`%` procedure proc_productCategory_select(IN ProductCategory_ID int)
BEGIN 
	SELECT ProductID,CategoryID
		FROM Product_Category
			WHERE ProductCategoryID = ProductCategory_ID;
END;

