create
    definer = db2007u1@`%` procedure proc_store_select(IN Store_ID int)
BEGIN 
	SELECT Store_Name,Store_Phone,Store_Address
		FROM Store
			WHERE StoreID = Store_ID;
END;

