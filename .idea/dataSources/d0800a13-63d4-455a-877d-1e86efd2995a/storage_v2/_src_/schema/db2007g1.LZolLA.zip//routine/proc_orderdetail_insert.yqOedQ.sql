create
    definer = db2007u1@`%` procedure proc_orderdetail_insert(IN OrderDetail_ID char(8), IN Order_ID char(8),
                                                             IN Order_Name_Ip varchar(50),
                                                             IN Order_Phone_Ip varchar(15),
                                                             IN Order_Address_Ip varchar(200), IN Product_ID char(8),
                                                             IN Quantity_Ip int)
BEGIN 
	INSERT INTO OrderDetail(OrderDetailID,OrderID,Order_Name,Order_Phone,Order_Address,ProductID,Quantity)
		VALUES(OrderDetail_ID,Order_ID,Order_Name_Ip,Order_Phone_Ip,Order_Address_Ip,Product_ID,Quantity_Ip);
END;

