create
    definer = db2007u1@`%` procedure proc_productBrand_select(IN ProductBrand_ID int)
BEGIN 
	SELECT ProductID,BrandID
		FROM Product_Brand
			WHERE ProductBrandID = ProductBrand_ID;
END;

