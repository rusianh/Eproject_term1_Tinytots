create
    definer = db2007u1@`%` procedure proc_attribute_insert(IN Attribute_ID char(8), IN Attribute_Name_Ip varchar(50))
BEGIN 
	INSERT INTO Attribute(AttributeID,Attribute_Name)
		VALUES(Attribute_ID,Attribute_Name_Ip);
END;

