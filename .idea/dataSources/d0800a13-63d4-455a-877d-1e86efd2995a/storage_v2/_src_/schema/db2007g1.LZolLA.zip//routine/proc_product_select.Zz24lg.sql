create
    definer = db2007u1@`%` procedure proc_product_select(IN Product_ID char(8))
BEGIN 
	SELECT a.Product_Name,b.Name_Category,c.Brand_Name,d.Attribute_Name,e.Attribute_Value,g.Image_Name,a.Description_Product 
		FROM Product a,Category b,Brand c,Attribute d,AttributeValue e,Images g,Product_Category h,Product_Attribute i,Product_Brand k
			WHERE a.ProductID = h.ProductID AND b.CategoryID = h.CategoryID AND a.ProductID = k.ProductID AND c.BrandID = k.BrandID
				AND a.ProductID = i.ProductID AND d.AttributeID = i.AttributeID AND d.AttributeID = e.AttributeID AND a.ProductID = g.ProductID
					AND a.ProductID = Product_ID;
END;

