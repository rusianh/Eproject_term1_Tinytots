create
    definer = db2007u1@`%` procedure proc_brand_insert(IN Brand_ID char(8), IN Brand_Name_Ip varchar(50),
                                                       IN Brand_Address_Ip varchar(200))
BEGIN 
	INSERT INTO Brand(BrandID,Brand_Name,Brand_Address)
		VALUES(Brand_ID,Brand_Name_Ip,Brand_Address_Ip);
END;

