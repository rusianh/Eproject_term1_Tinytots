create
    definer = db2007u1@`%` procedure proc_product_update(IN Product_ID char(8), IN Product_Name_Ip varchar(50),
                                                         IN Download_Ip varchar(50),
                                                         IN Description_Product_Ip varchar(200))
BEGIN 
	UPDATE Product SET Product_Name = Product_Name_Ip,Download = Download_Ip,Description_Product = Description_Product_Ip
		WHERE ProductID = Product_ID;
END;

