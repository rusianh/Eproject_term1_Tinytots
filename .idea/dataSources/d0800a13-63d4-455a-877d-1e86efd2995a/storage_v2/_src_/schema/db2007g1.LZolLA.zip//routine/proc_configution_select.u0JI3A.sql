create
    definer = db2007u1@`%` procedure proc_configution_select(IN Configution_ID int)
BEGIN 
	SELECT SystemKey,SystemValue
		FROM Configution
			WHERE ConfigutionID = Configution_ID;
END;

