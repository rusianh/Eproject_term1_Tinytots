create
    definer = db2007u1@`%` procedure proc_orders_insert(IN Order_ID char(8), IN Payment_ID int, IN Transport_ID int,
                                                        IN StatusOrder_Ip varchar(50))
BEGIN 
	INSERT INTO Orders(OrderID,PaymentID,TransportID,StatusOrder)
		VALUES(Order_ID,Payment_ID,Transport_ID,StatusOrder_Ip);
END;

