create
    definer = root@localhost procedure proc_product_edit(IN id int, IN productName varchar(50), IN categoryId_ip int,
                                                         IN dcp text, IN productStatus varchar(30), IN brandid_ip int,
                                                         IN link text, IN price float)
BEGIN
update  `product`
SET
`Product_Name` = productName,
`CategoryID` = categoryId_ip,
`Description_Product` = dcp,
`Product_status` = productStatus,
`BrandID` = brandid_ip,
`ProductImage_link` = link,
`Product_Price` = price
WHERE `ProductID` = id ;

END;

