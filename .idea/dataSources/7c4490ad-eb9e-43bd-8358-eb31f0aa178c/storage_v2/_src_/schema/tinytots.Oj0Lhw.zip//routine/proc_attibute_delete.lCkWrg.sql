create
    definer = root@localhost procedure proc_attibute_delete(IN id int)
BEGIN

    delete from attribute where AttributeID = id;

END;

