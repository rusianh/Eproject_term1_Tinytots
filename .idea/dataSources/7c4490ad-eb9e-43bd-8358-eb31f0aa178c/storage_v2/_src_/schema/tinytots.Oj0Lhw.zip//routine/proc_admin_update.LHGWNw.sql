create
    definer = root@localhost procedure proc_admin_update(IN UserName_Ip varchar(50), IN Password_Ip varchar(200))
BEGIN
UPDATE Admins
SET Password = Password_Ip
WHERE UserName = UserName_Ip;
END;

