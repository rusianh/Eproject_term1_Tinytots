create
    definer = root@localhost procedure proc_customer_insert(IN code int, IN name varchar(50), IN phone int,
                                                            IN address varchar(200))
BEGIN
    insert into customer (CustomerCode, order_name, order_phone, order_address) value (code, name, phone, address);
END;

