create
    definer = root@localhost procedure proc_productAttribute_updateAttributeID(IN Product_ID int, IN Attribute_ID int)
BEGIN
UPDATE Product_Attribute
SET AttributeID = Attribute_ID
WHERE ProductID = Product_ID;
END;

