create
    definer = root@localhost procedure proc_brand_selectId(IN id int)
BEGIN
    SELECT BrandID, Brand_Name
    FROM brand where BrandID=id;

END;

