create
    definer = root@localhost procedure proc_product_selectID()
BEGIN
    SELECT ProductID
    FROM PRODUCT;


END;

