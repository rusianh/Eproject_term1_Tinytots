create
    definer = root@localhost procedure proc_attribute_update(IN Attribute_ID int, IN Attribute_Name_Ip varchar(50))
BEGIN
UPDATE Attribute
SET Attribute_Name = Attribute_Name_Ip
WHERE AttributeID = Attribute_ID;
END;

