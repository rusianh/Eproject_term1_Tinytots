create
    definer = root@localhost procedure proc_product_selectProductID_Attribute(IN idProduct int)
BEGIN
select b.ProductID,a.Attribute_Name from attribute a, product b, product_attribute c
where a.AttributeID = c.AttributeID and b.ProductID = c.ProductID and  c.ProductID = idProduct  ;

END;

