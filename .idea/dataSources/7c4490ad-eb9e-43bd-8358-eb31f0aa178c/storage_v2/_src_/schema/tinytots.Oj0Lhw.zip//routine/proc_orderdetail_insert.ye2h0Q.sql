create
    definer = root@localhost procedure proc_orderdetail_insert(IN Order_ID int, IN Product_ID int, IN Quantity_Ip int)
BEGIN
INSERT INTO OrderDetail( OrderID, ProductID, Quantity)
VALUES ( Order_ID, Product_ID, Quantity_Ip);
END;

