create
    definer = root@localhost procedure proc_category_selectName(IN Name_Category_Ip varchar(50))
BEGIN
SELECT CategoryID, Name_Category
FROM Category
WHERE Name_Category = Name_Category_Ip;
END;

