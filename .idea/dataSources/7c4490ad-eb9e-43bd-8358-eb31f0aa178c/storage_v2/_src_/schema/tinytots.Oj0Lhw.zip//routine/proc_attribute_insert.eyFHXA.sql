create
    definer = root@localhost procedure proc_attribute_insert(IN AttributeID_ip int, IN Attribute_Name_Ip varchar(50))
BEGIN
INSERT INTO Attribute(AttributeID, Attribute_Name)
VALUES ( AttributeID_ip,Attribute_Name_Ip);
END;

