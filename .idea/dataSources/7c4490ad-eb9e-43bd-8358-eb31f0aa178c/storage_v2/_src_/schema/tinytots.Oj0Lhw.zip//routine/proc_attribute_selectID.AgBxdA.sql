create
    definer = root@localhost procedure proc_attribute_selectID(IN Attribute_ID int)
BEGIN
SELECT Attribute_Name
FROM Attribute
WHERE AttributeID = Attribute_ID;
END;

