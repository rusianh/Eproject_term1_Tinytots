create
    definer = root@localhost procedure proc_attribute_selectAll()
BEGIN
SELECT Attribute_Name
FROM Attribute;

END;

