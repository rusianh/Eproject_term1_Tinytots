create
    definer = root@localhost procedure proc_productAttribute_delete(IN Product_ID int)
BEGIN
delete from product_attribute where ProductID = Product_ID;
END;

