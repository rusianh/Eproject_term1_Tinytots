create
    definer = root@localhost procedure proc_brand_selectAll()
BEGIN
SELECT BrandID, Brand_Name
FROM brand;

END;

