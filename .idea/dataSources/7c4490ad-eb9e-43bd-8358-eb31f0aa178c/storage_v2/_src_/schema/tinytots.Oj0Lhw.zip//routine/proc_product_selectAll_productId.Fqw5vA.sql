create
    definer = root@localhost procedure proc_product_selectAll_productId(IN ProductId_ip int)
BEGIN
SELECT *
FROM PRODUCT
WHERE ProductID = ProductId_ip;

END;

