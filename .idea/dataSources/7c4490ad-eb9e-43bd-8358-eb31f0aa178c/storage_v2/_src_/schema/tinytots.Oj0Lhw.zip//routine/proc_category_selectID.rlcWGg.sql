create
    definer = root@localhost procedure proc_category_selectID(IN Category_ID int)
BEGIN
SELECT Name_Category
FROM Category
WHERE CategoryID = Category_ID;
END;

