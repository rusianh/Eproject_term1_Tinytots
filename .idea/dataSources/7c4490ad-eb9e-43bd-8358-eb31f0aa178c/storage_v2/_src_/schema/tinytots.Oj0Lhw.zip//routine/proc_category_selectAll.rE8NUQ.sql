create
    definer = root@localhost procedure proc_category_selectAll()
BEGIN
SELECT CategoryID, Name_Category
FROM Category;

END;

