create
    definer = root@localhost procedure proc_customer_selectID(IN id int)
BEGIN
    select * from customer where CustomerCode = id;
END;

