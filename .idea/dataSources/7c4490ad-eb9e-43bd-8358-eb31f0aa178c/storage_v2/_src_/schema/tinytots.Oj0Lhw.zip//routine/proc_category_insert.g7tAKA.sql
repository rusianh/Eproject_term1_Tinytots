create
    definer = root@localhost procedure proc_category_insert(IN Name_Category_Ip varchar(50))
BEGIN
INSERT INTO Category( Name_Category)
VALUES (Name_Category_Ip);
END;

