create
    definer = root@localhost procedure proc_product_selectAll()
BEGIN
select * from product;
END;

