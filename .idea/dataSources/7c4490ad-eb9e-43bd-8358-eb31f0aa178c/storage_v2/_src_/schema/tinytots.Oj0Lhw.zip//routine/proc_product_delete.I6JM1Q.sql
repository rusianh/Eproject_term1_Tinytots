create
    definer = root@localhost procedure proc_product_delete(IN ProductId_ip int)
BEGIN
delete from product where ProductID = ProductId_ip;

END;

