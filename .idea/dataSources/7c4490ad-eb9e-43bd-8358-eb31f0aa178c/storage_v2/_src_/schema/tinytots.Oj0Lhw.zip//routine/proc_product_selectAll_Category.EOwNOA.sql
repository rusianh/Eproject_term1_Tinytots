create
    definer = root@localhost procedure proc_product_selectAll_Category(IN CategoryId_ip int)
BEGIN
SELECT *
FROM PRODUCT
WHERE CategoryID = CategoryId_ip;

END;

