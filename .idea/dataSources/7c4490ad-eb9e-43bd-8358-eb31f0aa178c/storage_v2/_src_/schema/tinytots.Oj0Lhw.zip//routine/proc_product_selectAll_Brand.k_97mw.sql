create
    definer = root@localhost procedure proc_product_selectAll_Brand(IN BrandId_ip int)
BEGIN
SELECT *
FROM PRODUCT
WHERE BrandID = BrandId_ip;

END;

