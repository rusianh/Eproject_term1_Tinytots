create
    definer = root@localhost procedure proc_admin_insert(IN UserName_Ip varchar(50), IN Password_Ip varchar(200),
                                                         IN Name_Admin_Ip varchar(50))
BEGIN
INSERT INTO Admins(UserName, Password, Name_Admin)
VALUES (UserName_Ip, Password_Ip, Name_Admin_Ip);
END;

