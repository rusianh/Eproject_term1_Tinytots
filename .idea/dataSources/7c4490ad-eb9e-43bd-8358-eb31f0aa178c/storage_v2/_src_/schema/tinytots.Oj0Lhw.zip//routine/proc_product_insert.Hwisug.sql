create
    definer = root@localhost procedure proc_product_insert(IN ProductID_ip int, IN Product_Name_Ip varchar(50),
                                                           IN CategoryID_Ip int, IN BrandID_Ip int,
                                                           IN Product_status_Ip varchar(20),
                                                           IN Description_Product_Ip varchar(200),
                                                           IN Product_Price_Ip float, IN ProductImage_Link_Ip text)
BEGIN
INSERT INTO `product`
(  `ProductID`,
 `Product_Name`,
 `CategoryID`,
 `Description_Product`,
 `Product_status`,
 `BrandID`,
 `ProductImage_link`,
 `Product_Price`)
VALUES
    (
    ProductID_ip,
    Product_Name_Ip,
    CategoryID_Ip,
    Description_Product_Ip,
    Product_status_Ip,
    BrandID_Ip,
    ProductImage_Link_Ip,
    Product_Price_Ip);


END;

