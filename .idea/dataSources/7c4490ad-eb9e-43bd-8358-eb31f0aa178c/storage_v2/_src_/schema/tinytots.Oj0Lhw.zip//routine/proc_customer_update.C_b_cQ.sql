create
    definer = root@localhost procedure proc_customer_update(IN id int, IN name varchar(50), IN address varchar(200), IN phone int)
BEGIN
    update customer
    set Order_Name=name,
        Order_Address = address,
        Order_Phone = phone
    where CustomerCode = id ;

END;

