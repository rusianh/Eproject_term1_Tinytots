create
    definer = root@localhost procedure proc_orders_insert(IN Id int, IN CustomerCode_Ip int)
BEGIN
    INSERT
INTO `orders`
(
 `OrderID`,
`CustomerCode`)
VALUES
(
Id,

CustomerCode_Ip );

END;

