create
    definer = root@localhost procedure proc_ordersCustomer_selectAll()
BEGIN
    select a.OrderID , b.Order_Name, b.Order_Phone, b.Order_Address from orders a, customer b where a.CustomerCode = b.CustomerCode;
END;

