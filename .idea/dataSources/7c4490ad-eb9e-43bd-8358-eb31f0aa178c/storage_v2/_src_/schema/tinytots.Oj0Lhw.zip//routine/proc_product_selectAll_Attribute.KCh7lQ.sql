create
    definer = root@localhost procedure proc_product_selectAll_Attribute()
BEGIN
    select b.ProductID, a.Attribute_Name, a.AttributeID
    from attribute a,
         product b,
         product_attribute c
    where a.AttributeID = c.AttributeID
      and b.ProductID = c.ProductID;

END;

