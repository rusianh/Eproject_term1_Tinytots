create
    definer = root@localhost procedure proc_customer_selectAll()
BEGIN
    select * from customer;
END;

