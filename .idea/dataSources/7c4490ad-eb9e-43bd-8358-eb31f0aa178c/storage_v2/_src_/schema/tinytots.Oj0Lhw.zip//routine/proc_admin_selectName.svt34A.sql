create
    definer = root@localhost procedure proc_admin_selectName(IN UserName_Ip varchar(50))
BEGIN
    SELECT *
    FROM Admins
    WHERE UserName = UserName_Ip;
END;

