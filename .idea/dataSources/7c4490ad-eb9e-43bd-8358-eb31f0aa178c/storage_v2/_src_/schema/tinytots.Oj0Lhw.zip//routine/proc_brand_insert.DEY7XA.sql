create
    definer = root@localhost procedure proc_brand_insert(IN Brand_Name_Ip varchar(50))
BEGIN
INSERT INTO Brand(Brand_Name )
VALUES (Brand_Name_Ip);
END;

