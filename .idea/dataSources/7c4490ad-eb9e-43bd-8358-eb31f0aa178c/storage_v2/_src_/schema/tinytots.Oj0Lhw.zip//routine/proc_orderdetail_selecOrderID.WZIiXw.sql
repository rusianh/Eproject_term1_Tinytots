create
    definer = root@localhost procedure proc_orderdetail_selecOrderID(IN OrderID_ip int)
BEGIN
select * from orderdetail where OrderID = OrderID_ip;

END;

