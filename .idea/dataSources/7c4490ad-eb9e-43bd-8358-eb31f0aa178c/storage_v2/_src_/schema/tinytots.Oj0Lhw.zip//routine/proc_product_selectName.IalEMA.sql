create
    definer = root@localhost procedure proc_product_selectName(IN name varchar(200))
BEGIN
select Product_Name, ProductID from product where Product_Name = name;
END;

