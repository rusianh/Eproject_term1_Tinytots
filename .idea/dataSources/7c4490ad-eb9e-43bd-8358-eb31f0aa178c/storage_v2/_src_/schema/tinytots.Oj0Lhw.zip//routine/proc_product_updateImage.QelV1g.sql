create
    definer = root@localhost procedure proc_product_updateImage(IN ProductId_ip int, IN link text)
BEGIN
update product set ProductImage_link = link
WHERE ProductID = ProductId_ip;

END;

