create
    definer = root@localhost procedure proc_category_update(IN Category_ID int, IN Name_Category_Ip varchar(50))
BEGIN
UPDATE Category
SET Name_Category = Name_Category_Ip
WHERE CategoryID = Category_ID;
END;

