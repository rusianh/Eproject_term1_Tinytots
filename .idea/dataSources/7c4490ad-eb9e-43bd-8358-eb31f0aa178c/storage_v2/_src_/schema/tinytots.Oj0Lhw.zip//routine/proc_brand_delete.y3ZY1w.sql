create
    definer = root@localhost procedure proc_brand_delete(IN id int)
BEGIN
    delete from brand where BrandID = id;
END;

