create
    definer = root@localhost procedure proc_brand_selectName(IN Brand_Name_Ip varchar(50))
BEGIN
select * from brand where Brand_Name = Brand_Name_Ip;
END;

