create
    definer = root@localhost procedure proc_orderdetail_updateProduct(IN OrderDetail_ID int, IN Product_ID int, IN Quantity_Ip int)
BEGIN
update orderdetail set ProductID = Product_ID, Quantity = Quantity_Ip where OrderDetailID = OrderDetail_ID ;
 end;

