create
    definer = root@localhost procedure proc_orderdetail_selecOrderDetailID(IN id int)
BEGIN
    select * from orderdetail where OrderDetailID = id;

END;

