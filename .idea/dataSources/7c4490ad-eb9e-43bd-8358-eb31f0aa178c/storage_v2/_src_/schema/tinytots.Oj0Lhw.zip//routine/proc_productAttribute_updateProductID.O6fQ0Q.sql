create
    definer = root@localhost procedure proc_productAttribute_updateProductID(IN Attribute_ID int, IN Product_ID int)
BEGIN
UPDATE Product_Attribute
SET ProductID = Product_ID
WHERE AttributeID = Attribute_ID;
END;

