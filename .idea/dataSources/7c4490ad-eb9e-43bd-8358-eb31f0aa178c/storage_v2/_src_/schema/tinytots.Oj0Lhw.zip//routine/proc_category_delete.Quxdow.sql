create
    definer = root@localhost procedure proc_category_delete(IN id int)
BEGIN
    delete from category where CategoryID = id;

END;

