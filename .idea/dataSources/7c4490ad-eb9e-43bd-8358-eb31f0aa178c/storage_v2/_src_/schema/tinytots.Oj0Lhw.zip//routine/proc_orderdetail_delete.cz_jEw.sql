create
    definer = root@localhost procedure proc_orderdetail_delete(IN id int)
BEGIN
    delete from orderdetail where OrderDetailID = id;

END;

