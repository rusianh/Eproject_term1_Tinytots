create
    definer = root@localhost procedure proc_brand_update(IN Brand_ID int, IN Brand_Name_Ip varchar(50))
BEGIN
UPDATE Brand
SET Brand_Name    = Brand_Name_Ip

WHERE BrandID = Brand_ID;
END;

