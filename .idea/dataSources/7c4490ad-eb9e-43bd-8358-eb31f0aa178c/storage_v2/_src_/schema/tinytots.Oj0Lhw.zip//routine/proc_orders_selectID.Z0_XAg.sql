create
    definer = root@localhost procedure proc_orders_selectID(IN Order_ID int)
BEGIN
    select * from orders where OrderID = Order_ID;
END;

